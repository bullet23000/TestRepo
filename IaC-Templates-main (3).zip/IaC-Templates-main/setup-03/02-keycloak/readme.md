# Keycloak setup

This setup is currently **not working**. Idea was to use keycloak together with some auth forwarder as traefik
middleware.