https://github.com/vdarkobar/Authelia
https://github.com/DavidIlie/kubernetes-setup/tree/master/8%20-%20authelia
https://github.com/authelia/chartrepo/tree/master/charts/authelia
https://medium.com/@TCheronneau/sso-with-traefik-and-kubernetes-d008f9a1328a