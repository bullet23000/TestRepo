# Operator Lifecycle Manager Module

With ideas and code from:

- https://github.com/cloud-native-toolkit/terraform-k8s-olm
- https://github.com/streamnative/terraform-helm-charts