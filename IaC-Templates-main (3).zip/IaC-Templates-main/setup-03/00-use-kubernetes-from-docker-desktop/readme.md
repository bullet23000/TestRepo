# Use the kubernetes in Docker Desktop

Apply this folder to create a the kube config next to the terraform.tfvars
