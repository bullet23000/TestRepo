# How To Structure a Terraform Project

The main parts of the tutorial chapter comes from
[https://www.digitalocean.com/community/tutorials/how-to-structure-a-terraform-project](https://www.digitalocean.com/community/tutorials/how-to-structure-a-terraform-project)

The change to the original tutorial is that we are not using the digitalocean services at all. So no DNS and private key
setup, instead we are using the local docker engine.

## Definitions

Droplet > Server