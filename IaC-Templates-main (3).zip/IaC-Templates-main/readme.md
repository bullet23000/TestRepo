# Infrastructure as code (IaC) - Templates

Hello and welcome in this repository!

To make is short ;)
This repository serves me currently as backup. I store here currently the beginnings of me with the IaC topic and try my
self out.

That does not mean that you can not take something for you and profit from it :)
But be aware that everything that you will find here is not supposed to run in a productive environment and can / has
security issues included!

Best regards, Tobias