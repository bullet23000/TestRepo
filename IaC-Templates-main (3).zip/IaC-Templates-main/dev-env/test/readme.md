# Test

Collection of scripts to test the installations
of the development environment.