export USERHOME=$HOME
docker-compose run --rm dev_env