# Windows Subsystem for Linux

## Assumptions

- WSL2 installed
- Ubuntu distro with the name ubuntu available
- Ubuntu distro running

## Note

The script "01_setup_wsl.ps1" is only handful in case you did not install WSL2 over the store.

## Links

- https://www.thomaspreischl.de/ansible-wsl-windows/
- https://github.com/thomaspreischl/install-wsl-and-ansible